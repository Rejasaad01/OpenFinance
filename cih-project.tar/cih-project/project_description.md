﻿OpenFinance – Project Description (Updated)

Project Name: OpenFinance

Type: AI-powered Personal Finance & Secure Conversational Banking Agent

Domain: FinTech, Open Finance, Embedded Finance, Banking Automation

Target Users: Individuals, freelancers, small business owners, and banking customers

Overview

OpenFinance is an intelligent financial agent designed to empower users to manage their personal finances efficiently while enabling secure conversational banking actions. Leveraging AI and rule-based logic, OpenFinance analyzes bank transaction data, acts as a virtual accountant, provides personalized financial advice, and allows users to perform banking operations through natural language (e.g., WhatsApp/Telegram) with multi-layer authentication.

Core Features (Phase 1 MVP)

1. Bank Transaction Analysis
- Reads bank transaction data from CSV/Excel files
- Normalizes and structures financial data
- Ensures secure local processing

1. Virtual Accountant
- Categorizes transactions (Food, Bills, Transport, Income, etc.)
- Generates total and monthly summaries
- Helps users understand spending behavior

1. Financial Advice
- Provides insights on spending habits
- Suggests saving optimizations
- Offers actionable financial recommendations

1. Embedded Loan & Banking Decisions
- Evaluates loan eligibility using rule-based logic
- Provides recommendations to improve eligibility
- Simulates loan scenarios

1. Conversational Banking with Secure Execution (NEW)
- Users interact via chat chatbot in platform
- AI parses intent (e.g., send money, check balance)
- Displays transaction summary before execution
- Multi-layer authentication:
- Face verification (biometric)
- OTP/PIN confirmation
- Executes (or simulates) banking actions securely

MVP Demo Roadmap

Step 1: Data Engine

- Upload CSV file
- Display transaction summary

Step 2: AI + Chat Simulation

- Simple chat interface (web or CLI)
- Parse commands like:

“send 200dh to Ahmed” and call api with json after parsing

Step 3: Confirmation Layer

- Show transaction details before execution

Step 4: Face Verification (Simulated)

- Basic webcam capture or mock validation

Step 5: OTP Simulation

- Fixed OTP (e.g., 123456)

Step 6: Execution Simulation

- Show success message

Demo Scenario (for judges)

1. Upload bank data
1. Ask: “How much did I spend on food?”
1. Ask: “Send 300dh to Yassine”
1. System:
- Parses request
- Shows confirmation
- Simulates face + OTP
- Executes transfer

Value Proposition

OpenFinance combines financial intelligence with secure banking automation. It simplifies money management while introducing a safe and intuitive way to interact with banking services through conversational interfaces.



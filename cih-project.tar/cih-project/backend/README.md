# OpenFinance Backend

AI-powered Personal Finance & Secure Conversational Banking Agent

## Architecture

```
backend/
├── node-backend/      # NestJS API (Port 3000)
└── python-service/    # FastAPI AI Service (Port 8000)
```

## Quick Start

### Prerequisites
- Node.js 18+
- Python 3.10+
- PostgreSQL 14+

---

### 1. Database Setup

```bash
# Create PostgreSQL database
psql -U postgres -c "CREATE DATABASE openfinance;"
```

---

### 2. Node.js Backend

```bash
cd node-backend

# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with your DATABASE_URL and JWT_SECRET

# Generate Prisma client & run migrations
npm run prisma:generate
npm run prisma:migrate

# Seed with demo data
npm run prisma:seed

# Start development server
npm run start:dev
```

API runs at: http://localhost:3000/api  
Swagger docs: http://localhost:3000/api/docs

---

### 3. Python Microservice

```bash
cd python-service

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env

# Start service
python -m app.main
```

API runs at: http://localhost:8000  
Swagger docs: http://localhost:8000/docs

---

## Environment Variables

### Node Backend (.env)
```
PORT=3000
DATABASE_URL="postgresql://postgres:password@localhost:5432/openfinance"
JWT_SECRET=your-super-secret-key
JWT_EXPIRES_IN=7d
PYTHON_SERVICE_URL=http://localhost:8000
```

### Python Service (.env)
```
PORT=8000
HOST=0.0.0.0
```

---

## API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register new user |
| POST | /api/auth/login | Login |

### Users
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/users/me | Get profile |
| GET | /api/users/dashboard | Dashboard summary |

### Transactions
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/transactions | Create transaction |
| GET | /api/transactions | List transactions |
| GET | /api/transactions/summary | AI-powered summary |
| POST | /api/transactions/upload | Upload CSV/Excel |

### Analytics
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/analytics | Full analysis |
| GET | /api/analytics/categories | Spending by category |
| GET | /api/analytics/trends | Monthly trends |
| POST | /api/analytics/loan-eligibility | Loan evaluation |
| POST | /api/analytics/advice | Financial advice |

### Chat (Conversational Banking)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/chat/message | Quick chat message |
| POST | /api/chat/sessions | New session |
| GET | /api/chat/sessions | List sessions |
| POST | /api/chat/sessions/:id/messages | Send to session |

### Wallet (CIH API - Mocked)
All wallet endpoints mirror the CIH Wallet Management Kit exactly:
- `POST /api/wallet?state=precreate|activate`
- `POST /api/wallet/clientinfo`
- `GET /api/wallet/operations?contractid=`
- `GET /api/wallet/balance?contractid=`
- `POST /api/wallet/cash/in?step=simulation|confirmation`
- `POST /api/wallet/cash/out?step=simulation|confirmation`
- `POST /api/wallet/cash/out/otp`
- `POST /api/wallet/transfer/wallet?step=simulation|confirmation`
- `POST /api/wallet/transfer/wallet/otp`
- `POST /api/wallet/transfer/virement?step=simulation|confirmation`
- `POST /api/wallet/transfer/virement/otp`
- `POST /api/wallet/cash/gab/out?step=simulation|confirmation`
- `POST /api/wallet/cash/gab/otp`
- `POST /api/wallet/Transfer/WalletToMerchant?step=simulation|confirmation`
- `POST /api/wallet/walletToMerchant/cash/out/otp`
- `POST /api/wallet/pro/qrcode/dynamic`
- `POST /api/merchants`
- `POST /api/merchant/activate`
- `POST /api/merchant/transaction/simulation`
- `POST /api/merchant/transaction/otp`
- `POST /api/merchant/transaction/confirmation`
- `POST /api/merchant/merchantToWallet/simulation`
- `POST /api/merchant/otp/send`
- `POST /api/merchant/merchantToWallet/confirmation`

### Python Service Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /analyze-transactions | Full transaction analysis |
| POST | /categorize | Categorize transactions |
| POST | /financial-advice | Personalized advice |
| POST | /loan-eligibility | Loan evaluation |
| POST | /parse-intent | NLP intent parsing |
| GET | /health | Health check |

---

## Demo Scenario (Hackathon)

1. **Register:** `POST /api/auth/register`
2. **Login:** `POST /api/auth/login`  
3. **Upload bank statement:** `POST /api/transactions/upload` (CSV/Excel)
4. **Ask in chat:** `POST /api/chat/message` → "How much did I spend on food?"
5. **Transfer money:** `POST /api/chat/message` → "Send 300 MAD to Yassine"
   - System shows confirmation summary
   - Reply "confirm"
   - Face verification (auto-approved in demo)
   - Enter OTP: **123456**
   - Transfer executed ✅

---

## Demo Credentials (after seed)
- Email: `demo@openfinance.ma`
- Password: `Password123!`
- Demo OTP: `123456`

---

## Tech Stack
- **Node.js**: NestJS + TypeScript + Prisma ORM
- **Python**: FastAPI + Pandas + NumPy + Scikit-learn
- **Database**: PostgreSQL
- **Auth**: JWT (HS256)
- **API Docs**: Swagger (OpenAPI 3.0)

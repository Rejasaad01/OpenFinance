const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  const hashedPassword = await bcrypt.hash('Password123!', 12);

  const user = await prisma.user.upsert({
    where: { email: 'demo@openfinance.ma' },
    update: {},
    create: {
      email: 'demo@openfinance.ma',
      password: hashedPassword,
      firstName: 'Alex',
      lastName: 'Morgan',
      phoneNumber: '212600000001',
      contractId: 'LAN240000000000001',
    },
  });

  console.log(`✅ Demo user: ${user.email}`);

  const transactions = [
    { amount: 15000, type: 'INCOME', category: 'Income', description: 'Monthly salary', date: new Date('2024-01-01') },
    { amount: 250, type: 'EXPENSE', category: 'Food', description: 'Carrefour groceries', date: new Date('2024-01-03') },
    { amount: 80, type: 'EXPENSE', category: 'Food', description: 'Restaurant lunch', date: new Date('2024-01-05') },
    { amount: 500, type: 'EXPENSE', category: 'Bills', description: 'Maroc Telecom internet', date: new Date('2024-01-07') },
    { amount: 200, type: 'EXPENSE', category: 'Transport', description: 'Uber rides', date: new Date('2024-01-10') },
    { amount: 350, type: 'EXPENSE', category: 'Shopping', description: 'Zara clothing', date: new Date('2024-01-12') },
    { amount: 120, type: 'EXPENSE', category: 'Entertainment', description: 'Netflix subscription', date: new Date('2024-01-15') },
    { amount: 15000, type: 'INCOME', category: 'Income', description: 'Monthly salary', date: new Date('2024-02-01') },
    { amount: 300, type: 'EXPENSE', category: 'Food', description: 'Label Vie groceries', date: new Date('2024-02-04') },
    { amount: 150, type: 'EXPENSE', category: 'Health', description: 'Pharmacie Centrale', date: new Date('2024-02-08') },
    { amount: 600, type: 'EXPENSE', category: 'Bills', description: 'Loyer appartement', date: new Date('2024-02-10') },
    { amount: 100, type: 'EXPENSE', category: 'Food', description: "McDonald's", date: new Date('2024-02-14') },
    { amount: 2000, type: 'INCOME', category: 'Income', description: 'Freelance project', date: new Date('2024-02-20') },
    { amount: 450, type: 'EXPENSE', category: 'Transport', description: 'Essence Total', date: new Date('2024-02-22') },
    { amount: 15000, type: 'INCOME', category: 'Income', description: 'Monthly salary', date: new Date('2024-03-01') },
    { amount: 280, type: 'EXPENSE', category: 'Food', description: 'Acima supermarket', date: new Date('2024-03-03') },
    { amount: 200, type: 'EXPENSE', category: 'Entertainment', description: 'Cinema + Spotify', date: new Date('2024-03-07') },
    { amount: 180, type: 'EXPENSE', category: 'Health', description: 'Médecin consultation', date: new Date('2024-03-12') },
    { amount: 500, type: 'EXPENSE', category: 'Shopping', description: 'Amazon order', date: new Date('2024-03-18') },
    { amount: 1500, type: 'EXPENSE', category: 'Bills', description: 'Assurance voiture', date: new Date('2024-03-25') },
  ];

  for (const tx of transactions) {
    await prisma.transaction.create({
      data: { ...tx, userId: user.id, currency: 'MAD', source: 'MANUAL' },
    });
  }

  console.log(`✅ Created ${transactions.length} demo transactions`);
  console.log('🎉 Seeding complete!\n');
  console.log('Demo credentials:');
  console.log('  Email: demo@openfinance.ma');
  console.log('  Password: Password123!');
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());

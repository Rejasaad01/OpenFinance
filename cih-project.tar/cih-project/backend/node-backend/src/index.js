require('./config'); // loads dotenv
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const swaggerUi = require('swagger-ui-express');
const config = require('./config');
const { errorHandler, notFound } = require('./middleware/errorHandler');

const authRouter = require('./routes/auth');
const usersRouter = require('./routes/users');
const transactionsRouter = require('./routes/transactions');
const walletRouter = require('./routes/wallet');
const analyticsRouter = require('./routes/analytics');
const chatRouter = require('./routes/chat');

const app = express();

app.use(cors({ origin: '*', methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Logger
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url} ${res.statusCode} ${Date.now() - start}ms`);
  });
  next();
});

// Ensure uploads directory exists
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

// Swagger docs
const swaggerDoc = {
  openapi: '3.0.0',
  info: { title: 'OpenFinance API', version: '1.0.0', description: 'AI-powered Personal Finance & Secure Conversational Banking Agent' },
  components: {
    securitySchemes: {
      bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
    },
  },
  security: [{ bearerAuth: [] }],
  tags: [
    { name: 'auth', description: 'Authentication endpoints' },
    { name: 'users', description: 'User management' },
    { name: 'transactions', description: 'Transaction management' },
    { name: 'wallet', description: 'CIH Wallet operations' },
    { name: 'analytics', description: 'Financial analytics' },
    { name: 'chat', description: 'Conversational banking' },
  ],
};

app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerDoc));

// Routes
app.use('/api/auth', authRouter);
app.use('/api/users', usersRouter);
app.use('/api/transactions', transactionsRouter);
app.use('/api', walletRouter);
app.use('/api/analytics', analyticsRouter);
app.use('/api/chat', chatRouter);

app.get('/api/health', async (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use(notFound);
app.use(errorHandler);

app.listen(config.port, () => {
  console.log(`🚀 OpenFinance API running on: http://localhost:${config.port}/api`);
  console.log(`📚 Swagger docs: http://localhost:${config.port}/api/docs`);
});

module.exports = app;

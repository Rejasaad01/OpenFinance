function errorHandler(err, req, res, next) {
  const status = err.status || err.statusCode || 500;
  const message = err.message || 'Internal server error';

  if (process.env.NODE_ENV !== 'production') {
    console.error(`[${new Date().toISOString()}] ${req.method} ${req.url} - ${status}: ${message}`);
    if (err.stack) console.error(err.stack);
  }

  res.status(status).json({ statusCode: status, message });
}

function notFound(req, res) {
  res.status(404).json({ statusCode: 404, message: `Route ${req.method} ${req.url} not found` });
}

module.exports = { errorHandler, notFound };

const prisma = require('../prisma');
const pythonBridge = require('./pythonBridgeService');

async function getAnalytics(userId) {
  const transactions = await prisma.transaction.findMany({ where: { userId }, orderBy: { date: 'desc' } });

  if (transactions.length === 0) {
    return { message: 'No transactions found. Upload a CSV or add transactions to see analytics.', totalIncome: 0, totalExpenses: 0, netBalance: 0, categories: {}, monthly: {}, insights: [] };
  }

  try {
    const analysis = await pythonBridge.analyzeTransactions(transactions);
    await prisma.analyticsResult.create({ data: { userId, type: 'SPENDING_ANALYSIS', data: analysis } });
    return analysis;
  } catch (err) {
    console.warn(`Python service unavailable, computing locally: ${err.message}`);
    return computeLocalAnalytics(transactions);
  }
}

async function getLoanEligibility(userId, requestedAmount, durationMonths) {
  const transactions = await prisma.transaction.findMany({ where: { userId } });

  const income = transactions.filter((t) => t.type === 'INCOME').reduce((s, t) => s + t.amount, 0);
  const expenses = transactions.filter((t) => t.type === 'EXPENSE').reduce((s, t) => s + t.amount, 0);
  const months = new Set(transactions.map((t) => `${new Date(t.date).getFullYear()}-${new Date(t.date).getMonth()}`)).size || 1;
  const monthlyIncome = income / months;
  const monthlyExpenses = expenses / months;

  try {
    const result = await pythonBridge.getLoanEligibility({
      monthly_income: monthlyIncome, monthly_expenses: monthlyExpenses,
      requested_amount: requestedAmount, duration_months: durationMonths, transactions,
    });
    await prisma.analyticsResult.create({ data: { userId, type: 'LOAN_EVALUATION', data: result } });
    return result;
  } catch (err) {
    console.warn(`Python loan evaluation failed, computing locally: ${err.message}`);
    return computeLocalLoanEligibility(monthlyIncome, monthlyExpenses, requestedAmount, durationMonths);
  }
}

async function getFinancialAdvice(userId, goal) {
  const transactions = await prisma.transaction.findMany({ where: { userId }, orderBy: { date: 'desc' }, take: 100 });

  try {
    const result = await pythonBridge.getFinancialAdvice({ transactions, goal });
    await prisma.analyticsResult.create({ data: { userId, type: 'FINANCIAL_ADVICE', data: result } });
    return result;
  } catch (err) {
    console.warn(`Python advice failed, using defaults: ${err.message}`);
    return getDefaultAdvice(transactions);
  }
}

async function getSpendingByCategory(userId) {
  const result = await prisma.transaction.groupBy({
    by: ['category'],
    where: { userId, type: 'EXPENSE' },
    _sum: { amount: true },
    _count: true,
  });

  return result
    .filter((r) => r.category)
    .map((r) => ({ category: r.category, total: r._sum.amount || 0, count: r._count }))
    .sort((a, b) => b.total - a.total);
}

async function getMonthlyTrends(userId) {
  const transactions = await prisma.transaction.findMany({ where: { userId }, orderBy: { date: 'asc' } });
  const monthly = {};

  for (const t of transactions) {
    const key = `${new Date(t.date).getFullYear()}-${String(new Date(t.date).getMonth() + 1).padStart(2, '0')}`;
    if (!monthly[key]) monthly[key] = { income: 0, expenses: 0 };
    if (t.type === 'INCOME') monthly[key].income += t.amount;
    else monthly[key].expenses += t.amount;
  }

  return Object.entries(monthly).map(([month, data]) => ({ month, ...data, net: data.income - data.expenses }));
}

async function getHistory(userId) {
  return prisma.analyticsResult.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 10 });
}

function computeLocalAnalytics(transactions) {
  const income = transactions.filter((t) => t.type === 'INCOME').reduce((s, t) => s + t.amount, 0);
  const expenses = transactions.filter((t) => t.type === 'EXPENSE').reduce((s, t) => s + t.amount, 0);
  const byCategory = {};
  const monthly = {};

  for (const t of transactions) {
    if (t.category) byCategory[t.category] = (byCategory[t.category] || 0) + t.amount;
    const key = `${new Date(t.date).getFullYear()}-${String(new Date(t.date).getMonth() + 1).padStart(2, '0')}`;
    if (!monthly[key]) monthly[key] = { income: 0, expenses: 0 };
    if (t.type === 'INCOME') monthly[key].income += t.amount;
    else monthly[key].expenses += t.amount;
  }

  const topCategory = Object.entries(byCategory).sort((a, b) => b[1] - a[1])[0];
  const savingsRate = income > 0 ? ((income - expenses) / income) * 100 : 0;

  return {
    totalIncome: income, totalExpenses: expenses, netBalance: income - expenses,
    savingsRate: Math.round(savingsRate), transactionCount: transactions.length,
    categories: byCategory, monthly,
    insights: [
      `Your savings rate is ${Math.round(savingsRate)}%`,
      topCategory ? `Highest spending category: ${topCategory[0]} (${topCategory[1].toFixed(2)} MAD)` : null,
      income > expenses ? 'Great! You are spending less than you earn.' : 'Warning: Your expenses exceed your income.',
    ].filter(Boolean),
  };
}

function computeLocalLoanEligibility(monthlyIncome, monthlyExpenses, requestedAmount, durationMonths) {
  const monthlyPayment = requestedAmount / durationMonths;
  const disposable = monthlyIncome - monthlyExpenses;
  const debtToIncome = monthlyPayment / (monthlyIncome || 1);
  const savingsRate = disposable / (monthlyIncome || 1);

  let score = 100;
  const recommendations = [];

  if (savingsRate < 0.2) { score -= 30; recommendations.push('Increase your savings rate to at least 20% of income.'); }
  if (debtToIncome > 0.35) { score -= 40; recommendations.push('Reduce loan amount or extend repayment duration.'); }
  if (monthlyIncome < 3000) { score -= 20; recommendations.push('Minimum income of 3,000 MAD recommended.'); }

  return {
    eligible: score >= 50, score, maxLoanAmount: monthlyIncome * 48 * 0.35,
    monthlyPayment, debtToIncomeRatio: debtToIncome, savingsRate,
    monthlyIncome, monthlyExpenses, disposableIncome: disposable, recommendations,
  };
}

function getDefaultAdvice(transactions) {
  const expenses = transactions.filter((t) => t.type === 'EXPENSE').reduce((s, t) => s + t.amount, 0);
  const income = transactions.filter((t) => t.type === 'INCOME').reduce((s, t) => s + t.amount, 0);
  return {
    advice: [
      { title: 'Track Your Spending', description: 'Review your transactions weekly to identify wasteful spending.' },
      { title: 'Follow the 50/30/20 Rule', description: 'Allocate 50% to needs, 30% to wants, 20% to savings.' },
      { title: 'Build an Emergency Fund', description: 'Aim for 3-6 months of expenses in liquid savings.' },
      { title: 'Reduce Variable Expenses', description: 'Small daily purchases add up — consider tracking food and entertainment.' },
    ],
    summary: { totalIncome: income, totalExpenses: expenses, savingsOpportunity: income * 0.2 },
  };
}

module.exports = { getAnalytics, getLoanEligibility, getFinancialAdvice, getSpendingByCategory, getMonthlyTrends, getHistory };

const { v4: uuidv4 } = require('uuid');
const prisma = require('../prisma');

async function preCreateWallet(body) {
  const token = `TR${Date.now()}${Math.floor(Math.random() * 1000)}`;
  return {
    result: {
      activityArea: null, addressLine1: body.clientAddress || '', addressLine2: null,
      addressLine3: null, addressLine4: null, agenceId: '211', averageIncome: null,
      birthDay: null, channelId: 'P', city: null, country: null,
      dateOfBirth: body.dateOfBirth || '', distributeurId: '000104',
      documentExpiryDate1: null, documentExpiryDate2: null, documentScan1: '', documentScan2: '',
      documentType1: body.legalType || '', documentType2: null,
      email: body.email || '', familyStatus: null,
      firstName: body.clientFirstName || 'Prenom', fonction: null,
      gender: body.gender || '', institutionId: '0001', landLineNumber: null,
      lastName: body.clientLastName || 'nom', legalId1: body.legalId || '',
      legalId2: null, level: null, mailaddress: null,
      mobileNumber: body.phoneNumber || '', nationalite: null, numberofchildren: null,
      optField1: null, optField2: null, otp: '123456', phoneNumber: null,
      placeOfBirth: body.placeOfBirth || '', postCode: null,
      productId: '000', productTypeId: '000', profession: null,
      provider: body.phoneOperator || 'INWI', raisonSocial: null, region: null,
      registrationDate: null, title: null, token,
    },
  };
}

async function activateWallet(body) {
  if (body.otp !== '123456') return { error: 'Invalid OTP', code: 400 };
  const contractId = `LAN${Date.now()}${Math.floor(Math.random() * 10000)}`;
  const rib = `853${Math.floor(Math.random() * 1e20).toString().substring(0, 21)}`;
  return { result: { contractId, reference: '', level: '000', rib } };
}

async function getClientInfo(body) {
  return {
    result: {
      adressLine1: ' ', city: ' ', contractId: null, country: 'MAR',
      description: null, email: '', numberOfChildren: null,
      phoneNumber: body.phoneNumber, pidNUmber: null,
      pidType: body.identificationType || '',
      products: [{
        abbreviation: null, contractId: `LAN${Date.now()}`, description: null,
        email: '', level: '', name: 'CDP BASIC', phoneNumber: body.phoneNumber,
        productTypeId: '000', productTypeName: 'PARTICULIER', provider: 'ORANGE',
        rib: `853${Math.floor(Math.random() * 1e21).toString().substring(0, 21)}`,
        solde: '0.00', statusId: '1', tierType: '03', uid: '000',
      }],
      radical: '', soldeCumule: '0.00', statusId: null,
      tierFirstName: 'Prenom', tierId: `TR${Date.now()}`,
      tierLastName: 'nom', userName: null, familyStatus: null,
    },
  };
}

async function getOperations(contractId) {
  return {
    result: [{
      amount: '10.00', Fees: '4', beneficiaryFirstName: 'Prenom', beneficiaryLastName: 'nom',
      beneficiaryRIB: null, clientNote: 'W2W', contractId: null, currency: 'MAD',
      date: new Date().toLocaleString('en-GB'), dateToCompare: '0001-01-01T00:00:00Z',
      frais: [], numTel: null, operation: null,
      referenceId: Math.floor(Math.random() * 1e10).toString().padStart(10, '0'),
      sign: null, srcDestNumber: '212755123456', status: '000', totalAmount: '10.00',
      totalFrai: '6.00', type: 'MMD', isCanceled: false, isTierCashIn: false, totalPage: 1,
    }],
  };
}

async function getBalance(contractId) {
  return { result: { balance: [{ value: `${(Math.random() * 10000).toFixed(2)}` }] } };
}

async function cashInSimulation(body) {
  const token = uuidv4().replace(/-/g, '').toUpperCase();
  const transactionId = `${Date.now()}${Math.floor(Math.random() * 1000)}`;
  return {
    result: {
      Fees: '0.0',
      feeDetail: '[{Nature:"COM",InvariantFee:0.000,VariantFee:0.0000000}]',
      token, amountToCollect: parseFloat(body.amount), isTier: true,
      cardId: body.contractId, transactionId, benFirstName: 'Client', benLastName: 'CIH',
    },
  };
}

async function cashInConfirmation(body, userId) {
  const ref = Math.floor(Math.random() * 1e10).toString().padStart(10, '0');
  if (userId) {
    await prisma.walletOperation.create({
      data: { userId, type: 'CASH_IN', amount: parseFloat(body.amount), status: 'COMPLETED', referenceId: ref, token: body.token },
    });
  }
  return {
    result: {
      Fees: '0.0', feeDetails: null, token: body.token, amount: parseFloat(body.amount),
      transactionReference: ref, optFieldOutput1: null, optFieldOutput2: null,
      cardId: body.contractId || 'LAN000000000',
    },
  };
}

async function cashOutSimulation(body) {
  const token = uuidv4().replace(/-/g, '').toUpperCase();
  const transactionId = `${Date.now()}${Math.floor(Math.random() * 1000)}`;
  return {
    result: {
      Fees: '0.0', token, amountToCollect: parseFloat(body.amount), cashOut_Max: 5000,
      optFieldOutput1: null, optFieldOutput2: null, cardId: `LAN${Date.now()}`,
      transactionId, feeDetail: '[{Nature:"COM",InvariantFee:0.000,VariantFee:0.0000000}]',
    },
  };
}

async function cashOutOtp(body) {
  return { result: [{ codeOtp: '123456' }] };
}

async function cashOutConfirmation(body, userId) {
  if (body.otp !== '123456') return { error: 'Invalid OTP', code: 400 };
  const ref = Math.floor(Math.random() * 1e10).toString().padStart(10, '0');
  if (userId) {
    await prisma.walletOperation.create({
      data: { userId, type: 'CASH_OUT', amount: parseFloat(body.amount), status: 'COMPLETED', referenceId: ref, token: body.token },
    });
  }
  return {
    result: {
      Fees: '0.0', feeDetails: null, token: body.token, amount: parseFloat(body.amount),
      transactionReference: ref, optFieldOutput1: null, optFieldOutput2: null, cardId: `LAN${Date.now()}`,
    },
  };
}

async function w2wSimulation(body) {
  const referenceId = Math.floor(Math.random() * 1e10).toString().padStart(10, '0');
  const amount = parseFloat(body.amout || body.amount || '0');
  return {
    result: {
      amount: String(amount), Fees: '0.0', beneficiaryFirstName: 'Prenom',
      beneficiaryLastName: 'nom', beneficiaryRIB: null, contractId: null, currency: null,
      date: null, dateToCompare: '0001-01-01T00:00:00Z',
      frais: [
        { currency: 'MAD', fullName: '', name: 'COM', referenceId, value: 5 },
        { currency: 'MAD', fullName: '', name: 'TVA', referenceId, value: 1 },
      ],
      numTel: null, operation: null, referenceId, sign: null, srcDestNumber: null,
      status: null, totalAmount: String(amount), totalFrai: '6.00', type: 'TT',
      isCanceled: false, isTierCashIn: false,
    },
  };
}

async function w2wOtp(body) {
  return { result: [{ codeOtp: '123456' }] };
}

async function w2wConfirmation(body, userId) {
  if (body.otp !== '123456') return { error: 'Invalid OTP', code: 400 };
  const balance = `${(Math.random() * 50000).toFixed(3)}`;
  if (userId) {
    await prisma.walletOperation.create({
      data: { userId, type: 'W2W', amount: parseFloat(body.amount || '0'), status: 'COMPLETED', referenceId: body.referenceId, details: body },
    });
  }
  return {
    result: {
      item1: { creditAmounts: null, debitAmounts: null, depot: null, retrait: null, value: `-${balance}` },
      item2: '000', item3: 'Successful',
    },
  };
}

async function transferSimulation(body) {
  return {
    result: [{
      frais: '0', fraisSms: null, totalAmountWithFee: String(body.Amount || body.amount || '0'),
      deviseEmissionCode: null, fraisInclus: false, montantDroitTimbre: 0, montantFrais: 0,
      montantFraisSMS: 0, montantFraisTotal: 0, montantTVA: 0, montantTVASMS: 0, tauxChange: 0,
    }],
  };
}

async function transferOtp(body) {
  return { result: '123456' };
}

async function transferConfirmation(body, userId) {
  if (body.Otp !== '123456') return { error: 'Invalid OTP', code: 400 };
  const reference = Math.floor(Math.random() * 1e12).toString().padStart(12, '0');
  if (userId) {
    await prisma.walletOperation.create({
      data: { userId, type: 'TRANSFER', amount: parseFloat(body.Amount || '0'), status: 'COMPLETED', referenceId: reference, details: body },
    });
  }
  return { result: { contractId: body.ContractId, reference } };
}

async function atmSimulation(body) {
  const token = uuidv4().replace(/-/g, '').toUpperCase();
  const referenceId = Math.floor(Math.random() * 1e10).toString().padStart(10, '0');
  const amount = parseFloat(body.Amount || '0');
  return {
    result: {
      totalFrai: '3.00',
      feeDetails: '[{Nature:"COM",InvariantFee:3.000,VariantFee:0.0000000}]',
      token, totalAmount: amount + 3, referenceId,
    },
  };
}

async function atmOtp(body) {
  return { result: [{ codeOtp: '123456' }] };
}

async function atmConfirmation(body, userId) {
  if (body.Otp !== '123456') return { error: 'Invalid OTP', code: 400 };
  const transactionId = Math.floor(Math.random() * 2e9);
  const cihRef = `00230${Date.now()}`;
  if (userId) {
    await prisma.walletOperation.create({
      data: { userId, type: 'ATM', amount: 200, status: 'COMPLETED', referenceId: body.ReferenceId, token: body.Token },
    });
  }
  return {
    result: {
      fee: '0.00', feeDetails: null, token: uuidv4().replace(/-/g, '').toUpperCase(),
      amount: 200, transactionReference: '', cardId: body.ContractId,
      transactionId, transfertCihExpressReference: cihRef, redCode: null, greenCode: null,
    },
  };
}

async function w2mSimulation(body) {
  const referenceId = Math.floor(Math.random() * 1e10).toString().padStart(10, '0');
  const amount = parseFloat(body.Amout || body.amount || '0');
  return {
    result: {
      amount: String(amount), beneficiaryFirstName: 'Merchant', beneficiaryLastName: 'Name',
      beneficiaryRIB: null, clientNote: body.clientNote || '', contractId: null, currency: null,
      date: null, dateToCompare: '0001-01-01T00:00:00Z', frais: [], numTel: null, operation: null,
      referenceId, sign: null, srcDestNumber: null, status: null, totalAmount: String(amount),
      totalFrai: '0', type: 'TM', isCanceled: false, isTierCashIn: false,
      feeDetails: null, token: null, optFieldOutput1: null, optFieldOutput2: null, cardId: null, isSwitch: false,
    },
  };
}

async function w2mOtp(body) {
  return { result: [{ codeOtp: '123456' }] };
}

async function w2mConfirmation(body, userId) {
  if (body.OTP !== '123456') return { error: 'Invalid OTP', code: 400 };
  if (userId) {
    await prisma.walletOperation.create({
      data: { userId, type: 'W2M', amount: parseFloat(body.fees || '10'), status: 'COMPLETED', referenceId: body.ReferenceId, details: body },
    });
  }
  return {
    result: {
      item1: {
        creditAmounts: null, debitAmounts: null, depot: null, retrait: null,
        value: '17.460', transactionId: null, cardId: null,
        optFieldOutput2: null, optFieldOutput1: null, transactionReference: null,
        amount: null, token: null, fee: null, feeDetails: null,
      },
      item2: '000', item3: 'Successful',
    },
  };
}

async function preCreateMerchant(body) {
  const token = `ME${Date.now()}${Math.floor(Math.random() * 1000)}`;
  return { result: { token } };
}

async function activateMerchant(body) {
  if (body.Otp !== '123456') return { error: 'Invalid OTP', code: 400 };
  const contractId = `LAN${Date.now()}${Math.floor(Math.random() * 10000)}`;
  return { result: { contractId } };
}

async function m2mSimulation(body) {
  const referenceId = Math.floor(Math.random() * 1e10).toString().padStart(10, '0');
  const amount = parseFloat(body.Amount || '0');
  return {
    result: [{
      amount: String(amount), beneficiaryFirstName: 'Merchant', beneficiaryLastName: 'Two',
      beneficiaryRIB: null, clientNote: body.ClientNote || 'M2M', contractId: null, currency: null,
      date: null, dateToCompare: '0001-01-01T00:00:00Z',
      frais: [
        { currency: 'MAD', fullName: '', name: 'COM', referenceId, value: 3.33 },
        { currency: 'MAD', fullName: '', name: 'TVA', referenceId, value: 0.67 },
      ],
      numTel: null, operation: null, referenceId, sign: null, srcDestNumber: null,
      status: null, totalAmount: String(amount), totalFrai: '4.00', type: 'CC',
      isCanceled: false, isTierCashIn: false, walletType: '',
    }],
  };
}

async function m2mOtp(body) {
  return { result: [{ codeOtp: '123456' }] };
}

async function m2mConfirmation(body, userId) {
  if (body.Otp !== '123456') return { error: 'Invalid OTP', code: 400 };
  const balance = `${(Math.random() * 1000).toFixed(3)}`;
  return { result: { creditAmounts: null, debitAmounts: null, depot: null, retrait: null, value: balance } };
}

async function generateQrCode(body) {
  const token = `${Date.now()}${Math.floor(Math.random() * 1e12)}`;
  return {
    result: {
      phoneNumber: body.phoneNumber, reference: '', token,
      base64Content: 'iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAANklEQVQ4jWNgGAWDCvz//5+BEsz4n5KSmZmZlJWZmZmSmZmZmZWamZmZmpqamZmakpqamlkAAFYFCRFeWWMmAAAAAElFTkSuQmCC',
      binaryContent: `000201010212269300325bb66a92d69c0ea742dd4f754590fa0a020110501006240token${token}5052045411530350454031005802MA5907OpenFin6010Casablanca`,
    },
  };
}

async function m2wSimulation(body) {
  return { result: { amount: parseFloat(String(body.Amount)), feeAmount: 0.0 } };
}

async function m2wOtp(body) {
  return { result: '' };
}

async function m2wConfirmation(body, userId) {
  if (body.Otp !== '123456') return { error: 'Invalid OTP', code: 400 };
  const reference = Math.floor(Math.random() * 1e12).toString().padStart(12, '0');
  return { result: { contractId: null, reference, transferAmount: 0 } };
}

async function getOperationHistory(userId) {
  return prisma.walletOperation.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } });
}

module.exports = {
  preCreateWallet, activateWallet, getClientInfo, getOperations, getBalance,
  cashInSimulation, cashInConfirmation, cashOutSimulation, cashOutOtp, cashOutConfirmation,
  w2wSimulation, w2wOtp, w2wConfirmation, transferSimulation, transferOtp, transferConfirmation,
  atmSimulation, atmOtp, atmConfirmation, w2mSimulation, w2mOtp, w2mConfirmation,
  preCreateMerchant, activateMerchant, m2mSimulation, m2mOtp, m2mConfirmation,
  generateQrCode, m2wSimulation, m2wOtp, m2wConfirmation, getOperationHistory,
};

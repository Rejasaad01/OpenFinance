const { parse } = require('csv-parse/sync');
const XLSX = require('xlsx');
const prisma = require('../prisma');
const pythonBridge = require('./pythonBridgeService');

async function create(userId, { amount, type, category, description, date, currency, referenceId }) {
  return prisma.transaction.create({
    data: {
      userId, amount, type, category, description,
      date: new Date(date),
      currency: currency || 'MAD',
      referenceId,
      source: 'MANUAL',
    },
  });
}

async function findAll(userId, { category, type, startDate, endDate, page = 1, limit = 20 } = {}) {
  const skip = (Number(page) - 1) * Number(limit);
  const where = { userId };

  if (category) where.category = category;
  if (type) where.type = type;
  if (startDate || endDate) {
    where.date = {};
    if (startDate) where.date.gte = new Date(startDate);
    if (endDate) where.date.lte = new Date(endDate);
  }

  const [transactions, total] = await Promise.all([
    prisma.transaction.findMany({ where, orderBy: { date: 'desc' }, skip, take: Number(limit) }),
    prisma.transaction.count({ where }),
  ]);

  return {
    data: transactions,
    meta: { total, page: Number(page), limit: Number(limit), totalPages: Math.ceil(total / Number(limit)) },
  };
}

async function findOne(userId, id) {
  const transaction = await prisma.transaction.findFirst({ where: { id, userId } });
  if (!transaction) {
    const err = new Error('Transaction not found');
    err.status = 404;
    throw err;
  }
  return transaction;
}

async function deleteOne(userId, id) {
  await findOne(userId, id);
  await prisma.transaction.delete({ where: { id } });
  return { message: 'Transaction deleted' };
}

async function uploadCsvOrExcel(userId, file) {
  let rawTransactions;

  const ext = file.originalname.split('.').pop()?.toLowerCase();
  if (ext === 'csv') {
    rawTransactions = parseCsv(file.buffer);
  } else if (ext === 'xlsx' || ext === 'xls') {
    rawTransactions = parseExcel(file.buffer);
  } else {
    const err = new Error('Only CSV and Excel files are supported');
    err.status = 400;
    throw err;
  }

  if (!rawTransactions || rawTransactions.length === 0) {
    const err = new Error('File is empty or has no valid transactions');
    err.status = 400;
    throw err;
  }

  const normalized = normalizeTransactions(rawTransactions);

  let categorized = normalized;
  try {
    const result = await pythonBridge.categorize(normalized);
    if (result?.transactions) categorized = result.transactions;
  } catch (err) {
    console.warn(`Python categorization failed, using defaults: ${err.message}`);
  }

  const created = await prisma.$transaction(
    categorized.map((t) =>
      prisma.transaction.create({
        data: {
          userId,
          amount: t.amount,
          type: t.type || 'EXPENSE',
          category: t.category || 'Uncategorized',
          description: t.description || '',
          date: new Date(t.date),
          currency: t.currency || 'MAD',
          source: 'CSV_UPLOAD',
          metadata: t.raw || null,
        },
      }),
    ),
  );

  let analysis = null;
  try {
    analysis = await pythonBridge.analyzeTransactions(created);
  } catch (err) {
    console.warn(`Python analysis failed: ${err.message}`);
  }

  return { imported: created.length, transactions: created, analysis };
}

function parseCsv(buffer) {
  return parse(buffer.toString('utf-8'), { columns: true, skip_empty_lines: true, trim: true });
}

function parseExcel(buffer) {
  const workbook = XLSX.read(buffer, { type: 'buffer' });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  return XLSX.utils.sheet_to_json(sheet);
}

function findKey(obj, candidates) {
  for (const key of candidates) {
    if (obj[key] !== undefined) return key;
  }
  return candidates[0];
}

function normalizeTransactions(raw) {
  return raw.map((row) => {
    const amountKey = findKey(row, ['amount', 'montant', 'Amount', 'Montant', 'debit', 'credit']);
    const dateKey = findKey(row, ['date', 'Date', 'DATE', 'transaction_date']);
    const descKey = findKey(row, ['description', 'Description', 'libelle', 'Libellé', 'label', 'Label', 'note']);
    const typeKey = findKey(row, ['type', 'Type', 'operation']);

    const rawAmount = parseFloat(String(row[amountKey] || '0').replace(/[,\s]/g, '').replace(/[^0-9.-]/g, ''));
    const amount = Math.abs(rawAmount);
    const type = rawAmount < 0 ? 'EXPENSE'
      : (row[typeKey]?.toString().toLowerCase().includes('debit') ? 'EXPENSE' : 'INCOME');

    let date;
    try {
      date = new Date(row[dateKey]);
      if (isNaN(date.getTime())) date = new Date();
    } catch {
      date = new Date();
    }

    return { amount, type, description: row[descKey] || '', date: date.toISOString(), currency: 'MAD', raw: row };
  }).filter((t) => t.amount > 0);
}

async function getSummary(userId) {
  const transactions = await prisma.transaction.findMany({ where: { userId } });

  if (transactions.length === 0) {
    return { message: 'No transactions found', totalIncome: 0, totalExpenses: 0, netBalance: 0 };
  }

  try {
    return await pythonBridge.analyzeTransactions(transactions);
  } catch (err) {
    console.warn(`Python analysis failed, computing basic summary: ${err.message}`);
    return computeBasicSummary(transactions);
  }
}

function computeBasicSummary(transactions) {
  const income = transactions.filter((t) => t.type === 'INCOME').reduce((s, t) => s + t.amount, 0);
  const expenses = transactions.filter((t) => t.type === 'EXPENSE').reduce((s, t) => s + t.amount, 0);
  const byCategory = {};
  for (const t of transactions) {
    if (t.category) byCategory[t.category] = (byCategory[t.category] || 0) + t.amount;
  }
  return { totalIncome: income, totalExpenses: expenses, netBalance: income - expenses, byCategory, transactionCount: transactions.length };
}

module.exports = { create, findAll, findOne, deleteOne, uploadCsvOrExcel, getSummary };

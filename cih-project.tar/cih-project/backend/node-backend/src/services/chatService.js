const prisma = require('../prisma');
const walletService = require('./walletService');
const analyticsService = require('./analyticsService');

const Intent = {
  TRANSFER_MONEY: 'TRANSFER_MONEY',
  CHECK_BALANCE: 'CHECK_BALANCE',
  SPENDING_QUERY: 'SPENDING_QUERY',
  LOAN_QUERY: 'LOAN_QUERY',
  FINANCIAL_ADVICE: 'FINANCIAL_ADVICE',
  CONFIRM: 'CONFIRM',
  CANCEL: 'CANCEL',
  PROVIDE_OTP: 'PROVIDE_OTP',
  HELP: 'HELP',
  UNKNOWN: 'UNKNOWN',
};

const ChatState = {
  IDLE: 'IDLE',
  AWAITING_CONFIRMATION: 'AWAITING_CONFIRMATION',
  AWAITING_OTP: 'AWAITING_OTP',
};

async function getOrCreateSession(userId) {
  let session = await prisma.chatSession.findFirst({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    include: { messages: { orderBy: { createdAt: 'asc' }, take: 20 } },
  });

  if (!session) {
    session = await prisma.chatSession.create({
      data: { userId, state: ChatState.IDLE, context: {} },
      include: { messages: true },
    });
  }

  return session;
}

async function newSession(userId) {
  return prisma.chatSession.create({
    data: { userId, state: ChatState.IDLE, context: {} },
    include: { messages: true },
  });
}

async function sendMessage(userId, sessionId, userMessage) {
  const session = await prisma.chatSession.findFirst({ where: { id: sessionId, userId } });
  if (!session) {
    const err = new Error('Chat session not found');
    err.status = 404;
    throw err;
  }

  await prisma.chatMessage.create({ data: { sessionId, role: 'USER', content: userMessage } });

  const state = session.state;
  const context = session.context || {};
  let response, newState = state, newContext = context, metadata = null;

  if (state === ChatState.AWAITING_CONFIRMATION) {
    const parsed = parseIntent(userMessage.trim().toLowerCase());
    if (parsed.intent === Intent.CONFIRM || userMessage.toLowerCase().includes('confirm') || userMessage.toLowerCase() === 'yes' || userMessage === 'oui') {
      response = '🔍 Face verification required. In demo mode, face verification is automatically approved.\n\n✅ Face verified successfully! Now please enter your OTP (demo OTP: **123456**)';
      newState = ChatState.AWAITING_OTP;
    } else if (parsed.intent === Intent.CANCEL || userMessage.toLowerCase().includes('cancel') || userMessage === 'non') {
      response = '❌ Transaction cancelled. How else can I help you?';
      newState = ChatState.IDLE;
      newContext = {};
    } else {
      response = `Please confirm or cancel the transaction:\n\n${context.summary}\n\nType **confirm** to proceed or **cancel** to abort.`;
    }
  } else if (state === ChatState.AWAITING_OTP) {
    const otpMatch = userMessage.match(/\d{4,6}/);
    const otp = otpMatch ? otpMatch[0] : userMessage.trim();

    if (otp === '123456') {
      const result = await executeTransaction(userId, context, otp);
      response = result.message;
      metadata = result.data;
      newState = ChatState.IDLE;
      newContext = {};
    } else {
      response = '❌ Incorrect OTP. Please try again. (Demo OTP: **123456**)';
    }
  } else {
    const parsed = parseIntent(userMessage);
    response = await handleIntent(userId, parsed, session);
    if (parsed.intent === Intent.TRANSFER_MONEY) {
      newState = ChatState.AWAITING_CONFIRMATION;
      newContext = buildContext(parsed);
    }
  }

  await prisma.chatSession.update({ where: { id: sessionId }, data: { state: newState, context: newContext } });
  await prisma.chatMessage.create({
    data: { sessionId, role: 'ASSISTANT', content: response, metadata: metadata || undefined },
  });

  return { message: response, state: newState, metadata, sessionId };
}

function parseIntent(message) {
  const lower = message.toLowerCase();

  const transferPattern = /(?:send|transfer|envoyer|virer|pay)\s+(\d+\.?\d*)\s*(?:mad|dh|dhs|dirham)?\s+(?:to|à|a|vers)\s+(\w+)/i;
  const transferPattern2 = /(?:send|transfer|envoyer)\s+(?:to|à|a)\s+(\w+)\s+(\d+\.?\d*)/i;
  const transferMatch = message.match(transferPattern) || message.match(transferPattern2);

  if (transferMatch) {
    return { intent: Intent.TRANSFER_MONEY, amount: parseFloat(transferMatch[1] || transferMatch[2]), recipient: transferMatch[2] || transferMatch[1] };
  }

  if (/balance|solde|how much.*(have|do i)|mon compte/.test(lower)) return { intent: Intent.CHECK_BALANCE };

  const spendingMatch = message.match(/(?:how much|combien).*(?:spend|spent|dépensé|dépense)\s+(?:on|sur|for)?\s*(\w+)?/i) ||
    message.match(/(?:spending|dépenses|depenses)\s+(?:on|sur)?\s*(\w+)/i) ||
    message.match(/how much.*(?:food|transport|bills|shopping|health)/i);

  if (spendingMatch || /analyze.*spending|spending analysis|financial summary/.test(lower)) {
    const categoryMatch = message.match(/(?:on|sur|for)\s+(\w+)/i);
    return { intent: Intent.SPENDING_QUERY, category: categoryMatch?.[1] };
  }

  if (/loan|crédit|credit|borrow|emprunter|eligible|eligibilit/.test(lower)) {
    const amountMatch = message.match(/(\d+[\d,]*)\s*(?:mad|dh)?/);
    return { intent: Intent.LOAN_QUERY, loanAmount: amountMatch ? parseFloat(amountMatch[1].replace(',', '')) : undefined };
  }

  if (/advice|conseil|save|saving|budget|optimize|help me|tips|recommend/.test(lower)) return { intent: Intent.FINANCIAL_ADVICE, goal: message };
  if (/^(yes|oui|confirm|ok|proceed|execute)/.test(lower)) return { intent: Intent.CONFIRM };
  if (/^(no|non|cancel|annuler|abort|stop)/.test(lower)) return { intent: Intent.CANCEL };
  if (/^\d{4,6}$/.test(lower.trim())) return { intent: Intent.PROVIDE_OTP, rawOtp: lower.trim() };
  if (/help|aide|what can you do|commands|features/.test(lower)) return { intent: Intent.HELP };

  return { intent: Intent.UNKNOWN };
}

async function handleIntent(userId, parsed, session) {
  switch (parsed.intent) {
    case Intent.TRANSFER_MONEY: return handleTransfer(userId, parsed, session);
    case Intent.CHECK_BALANCE: return handleBalanceCheck(userId);
    case Intent.SPENDING_QUERY: return handleSpendingQuery(userId, parsed.category);
    case Intent.LOAN_QUERY: return handleLoanQuery(userId, parsed.loanAmount);
    case Intent.FINANCIAL_ADVICE: return handleFinancialAdvice(userId, parsed.goal);
    case Intent.HELP: return getHelpMessage();
    default: return getDefaultResponse();
  }
}

async function handleTransfer(userId, parsed, session) {
  const { amount, recipient } = parsed;
  if (!amount || !recipient) {
    return "I'd like to help you transfer money. Please specify the amount and recipient.\n\nExample: *\"Send 200 MAD to Ahmed\"*";
  }

  const simulation = await walletService.w2wSimulation({ amout: String(amount), contractId: 'LAN000000000', mobileNumber: '212666000000', destinationPhone: '212666111111' });
  const fees = simulation.result?.totalFrai || '0';
  const totalAmount = parseFloat(String(simulation.result?.totalAmount || amount)) + parseFloat(fees);

  const summary = `💸 **Transfer Summary**\n• Amount: **${amount} MAD**\n• Recipient: **${recipient}**\n• Fees: **${fees} MAD**\n• Total Deducted: **${totalAmount.toFixed(2)} MAD**\n\nType **confirm** to proceed or **cancel** to abort.`;

  await prisma.chatSession.update({
    where: { id: session.id },
    data: { context: { type: 'TRANSFER', amount, recipient, fees, totalAmount, summary, simulationData: simulation.result, referenceId: simulation.result?.referenceId } },
  });

  return summary;
}

async function handleBalanceCheck(userId) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  const contractId = user?.contractId || 'LAN000000000';
  const balance = await walletService.getBalance(contractId);
  const value = balance.result?.balance?.[0]?.value || '0.00';
  return `💰 **Your Wallet Balance**\n\n**${value} MAD**\n\nLast updated: ${new Date().toLocaleString('fr-MA')}`;
}

async function handleSpendingQuery(userId, category) {
  try {
    const analytics = await analyticsService.getAnalytics(userId);
    if (category) {
      const cats = analytics.categories || analytics.spending_by_category || {};
      const match = Object.entries(cats).find(([k]) => k.toLowerCase().includes(category.toLowerCase()));
      if (match) return `🛍️ **${category} Spending**\n\nYou spent **${Number(match[1]).toFixed(2)} MAD** on ${match[0]}.`;
      return `I couldn't find spending data for "${category}". Available categories: ${Object.keys(cats).join(', ')}.`;
    }

    const total = analytics.totalExpenses ?? analytics.total_expenses ?? 0;
    const income = analytics.totalIncome ?? analytics.total_income ?? 0;
    const insights = analytics.insights || analytics.recommendations || [];

    let response = `📊 **Financial Summary**\n\n• Total Income: **${Number(income).toFixed(2)} MAD**\n• Total Expenses: **${Number(total).toFixed(2)} MAD**\n• Net Savings: **${Number(income - total).toFixed(2)} MAD**\n\n`;
    if (insights.length > 0) response += `💡 **Insights:**\n${insights.slice(0, 3).map((i) => `• ${i}`).join('\n')}`;
    return response;
  } catch {
    return '📈 I couldn\'t retrieve your spending data. Please upload a bank statement first.';
  }
}

async function handleLoanQuery(userId, requestedAmount) {
  const amount = requestedAmount || 50000;
  try {
    const result = await analyticsService.getLoanEligibility(userId, amount, 24);
    const eligible = result.eligible ?? result.is_eligible;
    const score = result.score ?? result.eligibility_score ?? 0;
    const maxLoan = result.maxLoanAmount ?? result.max_loan_amount ?? 0;
    const recommendations = result.recommendations || result.suggestions || [];

    let response = `🏦 **Loan Eligibility Assessment**\n\n• Requested Amount: **${amount.toLocaleString()} MAD**\n• Eligibility Score: **${Number(score).toFixed(0)}/100**\n• Status: ${eligible ? '✅ **Eligible**' : '❌ **Not Eligible**'}\n• Maximum Loan: **${Number(maxLoan).toFixed(0)} MAD**\n\n`;
    if (recommendations.length > 0) response += `📝 **Recommendations:**\n${recommendations.map((r) => `• ${r}`).join('\n')}`;
    return response;
  } catch {
    return '🏦 Unable to evaluate loan eligibility. Please add your transaction data first.';
  }
}

async function handleFinancialAdvice(userId, goal) {
  try {
    const result = await analyticsService.getFinancialAdvice(userId, goal);
    const allAdvice = [...(result.advice || result.recommendations || []), ...(result.tips || [])];
    if (allAdvice.length === 0) return '💡 Upload your bank statement to get personalized financial advice.';

    let response = `💡 **Personalized Financial Advice**\n\n`;
    allAdvice.slice(0, 4).forEach((item) => {
      if (typeof item === 'string') response += `• ${item}\n`;
      else if (item.title) response += `**${item.title}**: ${item.description}\n\n`;
    });
    return response;
  } catch {
    return '💡 **Quick Financial Tips:**\n\n• Track every expense\n• Save 20% of income\n• Build 3-month emergency fund\n• Reduce impulse purchases';
  }
}

function buildContext(parsed) {
  return { type: parsed.intent, amount: parsed.amount, recipient: parsed.recipient, category: parsed.category };
}

async function executeTransaction(userId, context, otp) {
  if (context.type === 'TRANSFER') {
    const confirmation = await walletService.w2wConfirmation({
      mobileNumber: '212666000000', contractId: 'LAN000000000', otp,
      referenceId: context.referenceId || '0000000000', destinationPhone: '212666111111',
      fees: '0', amount: String(context.amount),
    }, userId);

    if (confirmation.result?.item3 === 'Successful') {
      await prisma.transaction.create({
        data: {
          userId, amount: context.amount, type: 'EXPENSE', category: 'Transfer',
          description: `Transfer to ${context.recipient}`, date: new Date(),
          source: 'WALLET_API', referenceId: context.referenceId,
        },
      });
      return {
        message: `✅ **Transfer Successful!**\n\n• Amount: **${context.amount} MAD**\n• Recipient: **${context.recipient}**\n• Reference: **${context.referenceId || 'N/A'}**\n\nTransaction recorded. How else can I help you?`,
        data: confirmation.result,
      };
    }
    return { message: '❌ Transfer failed. Please try again or contact support.', data: null };
  }
  return { message: '✅ Operation completed successfully.', data: null };
}

function getHelpMessage() {
  return `🤖 **OpenFinance Assistant - Available Commands**\n\n💸 **Transfer Money:**\n  "Send 200 MAD to Ahmed"\n\n💰 **Check Balance:**\n  "What's my balance?"\n\n📊 **Spending Analysis:**\n  "How much did I spend on food?"\n\n🏦 **Loan Eligibility:**\n  "Am I eligible for a 50,000 MAD loan?"\n\n💡 **Financial Advice:**\n  "Give me savings tips"`;
}

function getDefaultResponse() {
  return `I'm not sure I understand. Here's what I can help with:\n\n• 💸 Transfer money: *"Send 200 MAD to Ahmed"*\n• 💰 Check balance: *"What's my balance?"*\n• 📊 Spending analysis: *"How much did I spend on food?"*\n• 🏦 Loan advice: *"Can I get a loan?"*\n• 💡 Financial tips: *"Give me advice"*\n\nType **help** to see all commands.`;
}

async function getSessionMessages(userId, sessionId) {
  const session = await prisma.chatSession.findFirst({
    where: { id: sessionId, userId },
    include: { messages: { orderBy: { createdAt: 'asc' } } },
  });
  if (!session) {
    const err = new Error('Session not found');
    err.status = 404;
    throw err;
  }
  return session;
}

async function getSessions(userId) {
  return prisma.chatSession.findMany({
    where: { userId },
    orderBy: { updatedAt: 'desc' },
    include: { messages: { orderBy: { createdAt: 'desc' }, take: 1 } },
  });
}

module.exports = { getOrCreateSession, newSession, sendMessage, getSessionMessages, getSessions };

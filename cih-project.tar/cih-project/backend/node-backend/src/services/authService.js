const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config');
const prisma = require('../prisma');

function generateToken(userId, email) {
  return jwt.sign({ sub: userId, email }, config.jwt.secret, {
    expiresIn: config.jwt.expiresIn,
  });
}

async function register({ email, password, firstName, lastName, phoneNumber }) {
  const existingUser = await prisma.user.findUnique({ where: { email } });
  if (existingUser) {
    const err = new Error('Email already registered');
    err.status = 409;
    throw err;
  }

  if (phoneNumber) {
    const existingPhone = await prisma.user.findUnique({ where: { phoneNumber } });
    if (existingPhone) {
      const err = new Error('Phone number already registered');
      err.status = 409;
      throw err;
    }
  }

  const hashedPassword = await bcrypt.hash(password, 12);

  const user = await prisma.user.create({
    data: { email, password: hashedPassword, firstName, lastName, phoneNumber },
    select: { id: true, email: true, firstName: true, lastName: true, phoneNumber: true, createdAt: true },
  });

  console.log(`New user registered: ${user.email}`);
  return { user, access_token: generateToken(user.id, user.email) };
}

async function login({ email, password }) {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    const err = new Error('Invalid credentials');
    err.status = 401;
    throw err;
  }

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) {
    const err = new Error('Invalid credentials');
    err.status = 401;
    throw err;
  }

  const { password: _, ...userWithoutPassword } = user;
  console.log(`User logged in: ${user.email}`);
  return { user: userWithoutPassword, access_token: generateToken(user.id, user.email) };
}

module.exports = { register, login };

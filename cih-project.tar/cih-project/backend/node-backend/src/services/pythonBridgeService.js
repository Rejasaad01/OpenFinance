const axios = require('axios');
const axiosRetry = require('axios-retry').default;
const config = require('../config');

const client = axios.create({
  baseURL: config.pythonService.url,
  timeout: config.pythonService.timeout,
});

axiosRetry(client, {
  retries: 3,
  retryDelay: axiosRetry.exponentialDelay,
  retryCondition: (error) =>
    axiosRetry.isNetworkOrIdempotentRequestError(error) || error.code === 'ECONNREFUSED',
});

async function analyzeTransactions(transactions) {
  const response = await client.post('/analyze-transactions', { transactions });
  return response.data;
}

async function categorize(transactions) {
  const response = await client.post('/categorize', { transactions });
  return response.data;
}

async function getLoanEligibility(data) {
  const response = await client.post('/loan-eligibility', data);
  return response.data;
}

async function getFinancialAdvice(data) {
  const response = await client.post('/financial-advice', data);
  return response.data;
}

async function parseIntent(message, context) {
  try {
    const response = await client.post('/parse-intent', { message, context });
    return response.data;
  } catch {
    return null;
  }
}

async function healthCheck() {
  try {
    await client.get('/health', { timeout: 5000 });
    return true;
  } catch {
    return false;
  }
}

module.exports = { analyzeTransactions, categorize, getLoanEligibility, getFinancialAdvice, parseIntent, healthCheck };

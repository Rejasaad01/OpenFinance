const prisma = require('../prisma');

async function findById(id) {
  const user = await prisma.user.findUnique({
    where: { id },
    select: {
      id: true, email: true, firstName: true, lastName: true,
      phoneNumber: true, contractId: true, createdAt: true, updatedAt: true,
    },
  });
  if (!user) {
    const err = new Error('User not found');
    err.status = 404;
    throw err;
  }
  return user;
}

async function updateProfile(userId, { firstName, lastName, phoneNumber, contractId }) {
  return prisma.user.update({
    where: { id: userId },
    data: { firstName, lastName, phoneNumber, contractId },
    select: {
      id: true, email: true, firstName: true, lastName: true,
      phoneNumber: true, contractId: true, createdAt: true, updatedAt: true,
    },
  });
}

async function getDashboardSummary(userId) {
  const [transactionCount, recentTransactions] = await Promise.all([
    prisma.transaction.count({ where: { userId } }),
    prisma.transaction.findMany({ where: { userId }, orderBy: { date: 'desc' }, take: 5 }),
  ]);

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const monthlyStats = await prisma.transaction.groupBy({
    by: ['type'],
    where: { userId, date: { gte: thirtyDaysAgo } },
    _sum: { amount: true },
  });

  const income = monthlyStats.find((s) => s.type === 'INCOME')?._sum.amount || 0;
  const expenses = monthlyStats.find((s) => s.type === 'EXPENSE')?._sum.amount || 0;

  return {
    totalTransactions: transactionCount,
    monthlyIncome: income,
    monthlyExpenses: expenses,
    netBalance: income - expenses,
    recentTransactions,
  };
}

module.exports = { findById, updateProfile, getDashboardSummary };

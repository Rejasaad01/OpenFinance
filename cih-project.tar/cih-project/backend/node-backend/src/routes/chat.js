const { Router } = require('express');
const chatService = require('../services/chatService');
const auth = require('../middleware/auth');

const router = Router();
router.use(auth);

router.get('/sessions', async (req, res, next) => {
  try {
    res.json(await chatService.getSessions(req.user.id));
  } catch (err) { next(err); }
});

router.post('/sessions', async (req, res, next) => {
  try {
    res.status(201).json(await chatService.newSession(req.user.id));
  } catch (err) { next(err); }
});

router.get('/sessions/:sessionId', async (req, res, next) => {
  try {
    res.json(await chatService.getSessionMessages(req.user.id, req.params.sessionId));
  } catch (err) { next(err); }
});

router.post('/sessions/:sessionId/messages', async (req, res, next) => {
  try {
    res.json(await chatService.sendMessage(req.user.id, req.params.sessionId, req.body.message));
  } catch (err) { next(err); }
});

router.get('/current', async (req, res, next) => {
  try {
    res.json(await chatService.getOrCreateSession(req.user.id));
  } catch (err) { next(err); }
});

router.post('/message', async (req, res, next) => {
  try {
    const session = await chatService.getOrCreateSession(req.user.id);
    res.json(await chatService.sendMessage(req.user.id, session.id, req.body.message));
  } catch (err) { next(err); }
});

module.exports = router;

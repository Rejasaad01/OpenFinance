const { Router } = require('express');
const analyticsService = require('../services/analyticsService');
const auth = require('../middleware/auth');

const router = Router();
router.use(auth);

router.get('/', async (req, res, next) => {
  try {
    res.json(await analyticsService.getAnalytics(req.user.id));
  } catch (err) { next(err); }
});

router.get('/categories', async (req, res, next) => {
  try {
    res.json(await analyticsService.getSpendingByCategory(req.user.id));
  } catch (err) { next(err); }
});

router.get('/trends', async (req, res, next) => {
  try {
    res.json(await analyticsService.getMonthlyTrends(req.user.id));
  } catch (err) { next(err); }
});

router.get('/history', async (req, res, next) => {
  try {
    res.json(await analyticsService.getHistory(req.user.id));
  } catch (err) { next(err); }
});

router.post('/loan-eligibility', async (req, res, next) => {
  try {
    const { requestedAmount, durationMonths } = req.body;
    res.json(await analyticsService.getLoanEligibility(req.user.id, Number(requestedAmount), Number(durationMonths)));
  } catch (err) { next(err); }
});

router.post('/advice', async (req, res, next) => {
  try {
    res.json(await analyticsService.getFinancialAdvice(req.user.id, req.body.goal));
  } catch (err) { next(err); }
});

module.exports = router;

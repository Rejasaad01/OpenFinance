const { Router } = require('express');
const walletService = require('../services/walletService');
const auth = require('../middleware/auth');

const router = Router();
router.use(auth);

router.post('/wallet', async (req, res, next) => {
  try {
    const { state } = req.query;
    if (state === 'precreate') return res.json(await walletService.preCreateWallet(req.body));
    if (state === 'activate') return res.json(await walletService.activateWallet(req.body));
    res.status(400).json({ message: 'state must be precreate or activate' });
  } catch (err) { next(err); }
});

router.post('/wallet/clientinfo', async (req, res, next) => {
  try {
    res.json(await walletService.getClientInfo(req.body));
  } catch (err) { next(err); }
});

router.get('/wallet/operations', async (req, res, next) => {
  try {
    res.json(await walletService.getOperations(req.query.contractid));
  } catch (err) { next(err); }
});

router.get('/wallet/balance', async (req, res, next) => {
  try {
    res.json(await walletService.getBalance(req.query.contractid));
  } catch (err) { next(err); }
});

router.get('/wallet/history', async (req, res, next) => {
  try {
    res.json(await walletService.getOperationHistory(req.user.id));
  } catch (err) { next(err); }
});

router.post('/wallet/cash/in', async (req, res, next) => {
  try {
    const { step } = req.query;
    if (step === 'simulation') return res.json(await walletService.cashInSimulation(req.body));
    if (step === 'confirmation') return res.json(await walletService.cashInConfirmation(req.body, req.user.id));
    res.status(400).json({ message: 'step must be simulation or confirmation' });
  } catch (err) { next(err); }
});

router.post('/wallet/cash/out', async (req, res, next) => {
  try {
    const { step } = req.query;
    if (step === 'simulation') return res.json(await walletService.cashOutSimulation(req.body));
    if (step === 'confirmation') return res.json(await walletService.cashOutConfirmation(req.body, req.user.id));
    res.status(400).json({ message: 'step must be simulation or confirmation' });
  } catch (err) { next(err); }
});

router.post('/wallet/cash/out/otp', async (req, res, next) => {
  try {
    res.json(await walletService.cashOutOtp(req.body));
  } catch (err) { next(err); }
});

router.post('/wallet/transfer/wallet', async (req, res, next) => {
  try {
    const { step } = req.query;
    if (step === 'confirmation') return res.json(await walletService.w2wConfirmation(req.body, req.user.id));
    res.json(await walletService.w2wSimulation(req.body));
  } catch (err) { next(err); }
});

router.post('/wallet/transfer/wallet/otp', async (req, res, next) => {
  try {
    res.json(await walletService.w2wOtp(req.body));
  } catch (err) { next(err); }
});

router.post('/wallet/transfer/virement', async (req, res, next) => {
  try {
    const { step } = req.query;
    if (step === 'confirmation') return res.json(await walletService.transferConfirmation(req.body, req.user.id));
    res.json(await walletService.transferSimulation(req.body));
  } catch (err) { next(err); }
});

router.post('/wallet/transfer/virement/otp', async (req, res, next) => {
  try {
    res.json(await walletService.transferOtp(req.body));
  } catch (err) { next(err); }
});

router.post('/wallet/cash/gab/out', async (req, res, next) => {
  try {
    const { step } = req.query;
    if (step === 'simulation') return res.json(await walletService.atmSimulation(req.body));
    if (step === 'confirmation') return res.json(await walletService.atmConfirmation(req.body, req.user.id));
    res.status(400).json({ message: 'step required' });
  } catch (err) { next(err); }
});

router.post('/wallet/cash/gab/otp', async (req, res, next) => {
  try {
    res.json(await walletService.atmOtp(req.body));
  } catch (err) { next(err); }
});

router.post('/wallet/Transfer/WalletToMerchant', async (req, res, next) => {
  try {
    const { step } = req.query;
    if (step === 'confirmation') return res.json(await walletService.w2mConfirmation(req.body, req.user.id));
    res.json(await walletService.w2mSimulation(req.body));
  } catch (err) { next(err); }
});

router.post('/wallet/walletToMerchant/cash/out/otp', async (req, res, next) => {
  try {
    res.json(await walletService.w2mOtp(req.body));
  } catch (err) { next(err); }
});

router.post('/wallet/pro/qrcode/dynamic', async (req, res, next) => {
  try {
    res.json(await walletService.generateQrCode(req.body));
  } catch (err) { next(err); }
});

router.post('/merchants', async (req, res, next) => {
  try {
    res.status(201).json(await walletService.preCreateMerchant(req.body));
  } catch (err) { next(err); }
});

router.post('/merchant/activate', async (req, res, next) => {
  try {
    res.json(await walletService.activateMerchant(req.body));
  } catch (err) { next(err); }
});

router.post('/merchant/transaction/simulation', async (req, res, next) => {
  try {
    res.json(await walletService.m2mSimulation(req.body));
  } catch (err) { next(err); }
});

router.post('/merchant/transaction/otp', async (req, res, next) => {
  try {
    res.json(await walletService.m2mOtp(req.body));
  } catch (err) { next(err); }
});

router.post('/merchant/transaction/confirmation', async (req, res, next) => {
  try {
    res.json(await walletService.m2mConfirmation(req.body, req.user.id));
  } catch (err) { next(err); }
});

router.post('/merchant/merchantToWallet/simulation', async (req, res, next) => {
  try {
    res.json(await walletService.m2wSimulation(req.body));
  } catch (err) { next(err); }
});

router.post('/merchant/otp/send', async (req, res, next) => {
  try {
    res.json(await walletService.m2wOtp(req.body));
  } catch (err) { next(err); }
});

router.post('/merchant/merchantToWallet/confirmation', async (req, res, next) => {
  try {
    res.json(await walletService.m2wConfirmation(req.body, req.user.id));
  } catch (err) { next(err); }
});

module.exports = router;

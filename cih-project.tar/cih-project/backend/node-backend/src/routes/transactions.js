const { Router } = require('express');
const multer = require('multer');
const transactionsService = require('../services/transactionsService');
const auth = require('../middleware/auth');

const router = Router();
router.use(auth);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = file.originalname.split('.').pop()?.toLowerCase();
    if (!['csv', 'xlsx', 'xls'].includes(ext)) {
      return cb(Object.assign(new Error('Only CSV and Excel files are allowed'), { status: 400 }), false);
    }
    cb(null, true);
  },
});

router.post('/', async (req, res, next) => {
  try {
    res.status(201).json(await transactionsService.create(req.user.id, req.body));
  } catch (err) { next(err); }
});

router.get('/', async (req, res, next) => {
  try {
    res.json(await transactionsService.findAll(req.user.id, req.query));
  } catch (err) { next(err); }
});

router.get('/summary', async (req, res, next) => {
  try {
    res.json(await transactionsService.getSummary(req.user.id));
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    res.json(await transactionsService.findOne(req.user.id, req.params.id));
  } catch (err) { next(err); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    res.json(await transactionsService.deleteOne(req.user.id, req.params.id));
  } catch (err) { next(err); }
});

router.post('/upload', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file provided' });
    }
    res.json(await transactionsService.uploadCsvOrExcel(req.user.id, req.file));
  } catch (err) { next(err); }
});

module.exports = router;

const { Router } = require('express');
const usersService = require('../services/usersService');
const auth = require('../middleware/auth');

const router = Router();
router.use(auth);

router.get('/me', async (req, res, next) => {
  try {
    res.json(await usersService.findById(req.user.id));
  } catch (err) { next(err); }
});

router.put('/me', async (req, res, next) => {
  try {
    res.json(await usersService.updateProfile(req.user.id, req.body));
  } catch (err) { next(err); }
});

router.get('/dashboard', async (req, res, next) => {
  try {
    res.json(await usersService.getDashboardSummary(req.user.id));
  } catch (err) { next(err); }
});

module.exports = router;

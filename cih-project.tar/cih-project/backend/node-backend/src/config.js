require('dotenv').config();

module.exports = {
  port: parseInt(process.env.PORT, 10) || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  databaseUrl: process.env.DATABASE_URL,
  jwt: {
    secret: process.env.JWT_SECRET || 'openfinance-secret-key',
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  },
  pythonService: {
    url: process.env.PYTHON_SERVICE_URL || 'http://localhost:8000',
    timeout: parseInt(process.env.PYTHON_SERVICE_TIMEOUT, 10) || 30000,
  },
  upload: {
    maxFileSize: parseInt(process.env.MAX_FILE_SIZE, 10) || 10485760,
    uploadDir: process.env.UPLOAD_DIR || './uploads',
  },
};

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime


class Transaction(BaseModel):
    id: Optional[str] = None
    amount: float
    type: Optional[str] = "EXPENSE"
    category: Optional[str] = None
    description: Optional[str] = ""
    date: Optional[str] = None
    currency: Optional[str] = "MAD"
    source: Optional[str] = "MANUAL"
    referenceId: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    class Config:
        extra = "allow"


class TransactionList(BaseModel):
    transactions: List[Transaction]


class AnalyzeRequest(BaseModel):
    transactions: List[Dict[str, Any]]


class CategorizeRequest(BaseModel):
    transactions: List[Dict[str, Any]]


class LoanEligibilityRequest(BaseModel):
    monthly_income: float = Field(..., gt=0)
    monthly_expenses: float = Field(..., ge=0)
    requested_amount: float = Field(..., gt=0)
    duration_months: int = Field(..., gt=0)
    transactions: Optional[List[Dict[str, Any]]] = None


class FinancialAdviceRequest(BaseModel):
    transactions: List[Dict[str, Any]]
    goal: Optional[str] = None


class IntentRequest(BaseModel):
    message: str
    context: Optional[Dict[str, Any]] = None


class SpendingInsight(BaseModel):
    category: str
    total: float
    percentage: float
    trend: str


class MonthlyData(BaseModel):
    month: str
    income: float
    expenses: float
    net: float


class AnalysisResponse(BaseModel):
    total_income: float
    total_expenses: float
    net_balance: float
    savings_rate: float
    transaction_count: int
    spending_by_category: Dict[str, float]
    monthly_breakdown: List[Dict[str, Any]]
    top_expenses: List[Dict[str, Any]]
    insights: List[str]
    recommendations: List[str]
    risk_level: str


class CategorizedTransaction(BaseModel):
    amount: float
    type: str
    category: str
    description: Optional[str] = ""
    date: Optional[str] = None
    currency: str = "MAD"


class CategorizeResponse(BaseModel):
    transactions: List[Dict[str, Any]]
    category_summary: Dict[str, int]


class LoanEligibilityResponse(BaseModel):
    eligible: bool
    eligibility_score: float
    max_loan_amount: float
    monthly_payment: float
    debt_to_income_ratio: float
    savings_rate: float
    monthly_income: float
    monthly_expenses: float
    disposable_income: float
    recommendations: List[str]
    suggestions: List[str]
    risk_assessment: str


class AdviceItem(BaseModel):
    title: str
    description: str
    priority: str
    potential_savings: Optional[float] = None


class FinancialAdviceResponse(BaseModel):
    advice: List[AdviceItem]
    tips: List[str]
    summary: Dict[str, Any]
    action_plan: List[str]

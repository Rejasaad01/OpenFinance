import logging
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from app.routes.analysis import router as analysis_router
from app.routes.categorization import router as categorization_router
from app.routes.loan import router as loan_router

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🐍 OpenFinance Python Service starting up...")
    yield
    logger.info("🐍 OpenFinance Python Service shutting down...")


app = FastAPI(
    title="OpenFinance Python Service",
    description="AI-powered financial analysis, categorization, and insights microservice",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(analysis_router)
app.include_router(categorization_router)
app.include_router(loan_router)


@app.get("/health", tags=["system"])
async def health_check():
    return {
        "status": "healthy",
        "service": "openfinance-python-service",
        "version": "1.0.0",
    }


@app.get("/", tags=["system"])
async def root():
    return {
        "message": "OpenFinance Python Microservice",
        "docs": "/docs",
        "health": "/health",
        "endpoints": [
            "POST /analyze-transactions",
            "POST /categorize",
            "POST /financial-advice",
            "POST /loan-eligibility",
            "POST /parse-intent",
        ],
    }


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    uvicorn.run("app.main:app", host=host, port=port, reload=True)

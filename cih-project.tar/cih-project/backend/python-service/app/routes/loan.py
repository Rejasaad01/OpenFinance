from fastapi import APIRouter, HTTPException
from typing import Any, Dict
from app.models.schemas import LoanEligibilityRequest, LoanEligibilityResponse, IntentRequest
from app.services.loan_evaluator import evaluate_loan_eligibility
import re
import logging

router = APIRouter(tags=["loan"])
logger = logging.getLogger(__name__)


@router.post("/loan-eligibility", response_model=None)
async def loan_eligibility(request: LoanEligibilityRequest) -> Dict[str, Any]:
    """
    Evaluate loan eligibility based on income, expenses, and transaction history.
    """
    try:
        result = evaluate_loan_eligibility(
            monthly_income=request.monthly_income,
            monthly_expenses=request.monthly_expenses,
            requested_amount=request.requested_amount,
            duration_months=request.duration_months,
            transactions=request.transactions,
        )
        return result
    except Exception as e:
        logger.error(f"Loan evaluation error: {e}")
        raise HTTPException(status_code=500, detail=f"Loan evaluation failed: {str(e)}")


@router.post("/parse-intent", response_model=None)
async def parse_intent(request: IntentRequest) -> Dict[str, Any]:
    """
    Parse user intent from natural language message.
    """
    message = request.message.lower().strip()

    # Transfer
    transfer_match = re.search(
        r"(?:send|transfer|envoyer|virer|pay)\s+(\d+\.?\d*)\s*(?:mad|dh)?\s+(?:to|à|a|vers)\s+(\w+)",
        message, re.IGNORECASE
    )
    if transfer_match:
        return {
            "intent": "TRANSFER_MONEY",
            "amount": float(transfer_match.group(1)),
            "recipient": transfer_match.group(2),
            "confidence": 0.95,
        }

    if re.search(r"balance|solde|how much.*(have|do i)", message):
        return {"intent": "CHECK_BALANCE", "confidence": 0.9}

    spending_match = re.search(
        r"(?:how much|combien).*(?:spend|spent|dépensé)\s*(?:on|sur)?\s*(\w+)?",
        message, re.IGNORECASE
    )
    if spending_match or "spending" in message or "analyse" in message:
        return {
            "intent": "SPENDING_QUERY",
            "category": spending_match.group(1) if spending_match and spending_match.group(1) else None,
            "confidence": 0.85,
        }

    if re.search(r"loan|crédit|credit|borrow|eligible", message):
        amount_match = re.search(r"(\d[\d,]*)", message)
        return {
            "intent": "LOAN_QUERY",
            "amount": float(amount_match.group(1).replace(",", "")) if amount_match else None,
            "confidence": 0.85,
        }

    if re.search(r"advice|conseil|save|saving|budget|tip|recommend", message):
        return {"intent": "FINANCIAL_ADVICE", "confidence": 0.8}

    return {"intent": "UNKNOWN", "confidence": 0.0, "message": message}

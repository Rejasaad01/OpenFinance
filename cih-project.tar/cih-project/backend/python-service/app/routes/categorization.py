from fastapi import APIRouter, HTTPException
from typing import Any, Dict
from app.models.schemas import CategorizeRequest, CategorizeResponse, FinancialAdviceRequest
from app.services.categorizer import categorize_transactions, get_category_summary
from app.services.financial_advisor import get_financial_advice
import logging

router = APIRouter(tags=["categorization"])
logger = logging.getLogger(__name__)


@router.post("/categorize", response_model=None)
async def categorize(request: CategorizeRequest) -> Dict[str, Any]:
    """
    Categorize a list of transactions using rule-based NLP.
    """
    try:
        transactions = [t if isinstance(t, dict) else t.dict() for t in request.transactions]
        categorized = categorize_transactions(transactions)
        summary = get_category_summary(categorized)
        return {
            "transactions": categorized,
            "category_summary": summary,
        }
    except Exception as e:
        logger.error(f"Categorization error: {e}")
        raise HTTPException(status_code=500, detail=f"Categorization failed: {str(e)}")


@router.post("/financial-advice", response_model=None)
async def financial_advice(request: FinancialAdviceRequest) -> Dict[str, Any]:
    """
    Generate personalized financial advice based on transaction history.
    """
    try:
        result = get_financial_advice(request.transactions, request.goal)
        return result
    except Exception as e:
        logger.error(f"Financial advice error: {e}")
        raise HTTPException(status_code=500, detail=f"Financial advice failed: {str(e)}")

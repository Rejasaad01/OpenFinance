from fastapi import APIRouter, HTTPException
from typing import Any, Dict
from app.models.schemas import AnalyzeRequest, AnalysisResponse
from app.services.transaction_analyzer import analyze_transactions
import logging

router = APIRouter(tags=["analysis"])
logger = logging.getLogger(__name__)


@router.post("/analyze-transactions", response_model=None)
async def analyze(request: AnalyzeRequest) -> Dict[str, Any]:
    """
    Analyze a list of transactions and return comprehensive financial insights.
    """
    try:
        result = analyze_transactions(request.transactions)
        return result
    except Exception as e:
        logger.error(f"Analysis error: {e}")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

import re
from typing import Dict, List, Optional

CATEGORY_RULES: Dict[str, List[str]] = {
    "Food": [
        "restaurant", "café", "cafe", "food", "eat", "lunch", "dinner", "breakfast",
        "carrefour", "marjane", "label vie", "acima", "pizza", "burger", "sandwich",
        "snack", "boulangerie", "patisserie", "supermarket", "épicerie", "epicerie",
        "livraison", "takeaway", "fastfood", "mcdo", "kfc", "subway"
    ],
    "Transport": [
        "taxi", "uber", "careem", "bus", "train", "oncf", "ctm", "supratours",
        "fuel", "essence", "carburant", "parking", "autoroute", "péage", "peage",
        "vignette", "transport", "metro", "tram", "avion", "royal air maroc", "ram"
    ],
    "Bills": [
        "water", "eau", "electricity", "redal", "amendis", "radeef",
        "internet", "wifi", "maroc telecom", "orange", "inwi",
        "phone", "téléphone", "telephone", "loyer", "rent",
        "assurance", "insurance", "facture", "bill", "onee", "lydec"
    ],
    "Shopping": [
        "mall", "shopping", "magasin", "store", "amazon", "jumia", "glovo",
        "clothing", "vêtements", "vetements", "shoes", "chaussures", "aliexpress",
        "h&m", "zara", "bershka", "pull", "accessoire", "electronics"
    ],
    "Health": [
        "pharmacy", "pharmacie", "hospital", "hôpital", "hopital",
        "doctor", "médecin", "medecin", "clinique", "lab", "analyse",
        "medical", "médicament", "medicament", "dentist", "dentiste", "optique"
    ],
    "Entertainment": [
        "cinema", "film", "netflix", "spotify", "youtube", "prime",
        "game", "jeu", "sport", "gym", "fitness", "loisir", "concert",
        "theatre", "théâtre", "livre", "book", "abonnement", "subscription"
    ],
    "Education": [
        "school", "école", "ecole", "university", "université", "universite",
        "cours", "formation", "training", "tutoring", "books", "fournitures",
        "inscription", "scolarité", "scolarite", "college"
    ],
    "Income": [
        "salary", "salaire", "virement reçu", "virement recu", "income",
        "freelance", "payment received", "credit", "dépôt", "depot",
        "remboursement", "transfer in", "payment", "rémunération", "remuneration"
    ],
    "Savings": [
        "saving", "épargne", "epargne", "investissement", "investment",
        "dépôt épargne", "compte épargne", "plan épargne"
    ],
    "Transfer": [
        "w2w", "transfer", "virement", "envoi", "wallet to wallet",
        "money transfer", "tmt", "western union", "wafacash"
    ],
}

AMOUNT_HINTS: Dict[str, str] = {}


def categorize_transaction(description: str, amount: float, transaction_type: str) -> str:
    if transaction_type.upper() == "INCOME":
        return "Income"

    if not description:
        return "Uncategorized"

    desc_lower = description.lower()

    for category, keywords in CATEGORY_RULES.items():
        if category == "Income" and transaction_type.upper() == "EXPENSE":
            continue
        for keyword in keywords:
            if keyword.lower() in desc_lower:
                return category

    if amount < 20:
        return "Food"
    elif amount > 5000:
        return "Bills"

    return "Uncategorized"


def categorize_transactions(transactions: List[dict]) -> List[dict]:
    result = []
    for t in transactions:
        description = t.get("description", "") or ""
        amount = float(t.get("amount", 0))
        t_type = t.get("type", "EXPENSE")

        if not t.get("category") or t.get("category") == "Uncategorized":
            t["category"] = categorize_transaction(description, amount, t_type)

        if t_type.upper() in ("INCOME", "CREDIT") or any(
            kw in description.lower() for kw in CATEGORY_RULES["Income"]
        ):
            t["type"] = "INCOME"
            t["category"] = "Income"

        result.append(t)

    return result


def get_category_summary(transactions: List[dict]) -> Dict[str, int]:
    summary: Dict[str, int] = {}
    for t in transactions:
        cat = t.get("category", "Uncategorized")
        summary[cat] = summary.get(cat, 0) + 1
    return summary

from typing import Dict, Any, List, Optional
from app.services.transaction_analyzer import analyze_transactions


def get_financial_advice(
    transactions: List[Dict[str, Any]],
    goal: Optional[str] = None,
) -> Dict[str, Any]:
    analysis = analyze_transactions(transactions)

    total_income = analysis.get("total_income", 0)
    total_expenses = analysis.get("total_expenses", 0)
    net_balance = analysis.get("net_balance", 0)
    savings_rate = analysis.get("savings_rate", 0)
    categories = analysis.get("spending_by_category", {})

    advice_items = []
    tips = []
    action_plan = []

    # Core savings advice
    if savings_rate < 20:
        advice_items.append({
            "title": "Increase Your Savings Rate",
            "description": f"You're currently saving {savings_rate:.1f}% of income. Target 20% by reducing top spending categories.",
            "priority": "high",
            "potential_savings": round(total_income * 0.2 - max(net_balance, 0), 2),
        })
        action_plan.append(f"Set up automatic transfer of {round(total_income * 0.2, 0):.0f} MAD to savings each month.")

    # Budget rule
    needs = sum(v for k, v in categories.items() if k in ["Bills", "Food", "Health", "Transport"])
    wants = sum(v for k, v in categories.items() if k in ["Entertainment", "Shopping"])
    if total_income > 0:
        needs_pct = needs / total_income * 100
        wants_pct = wants / total_income * 100
        if needs_pct > 50:
            advice_items.append({
                "title": "Review Essential Spending",
                "description": f"Essential expenses ({needs_pct:.1f}%) exceed the recommended 50%. Look for ways to reduce bills.",
                "priority": "medium",
                "potential_savings": round((needs_pct - 50) / 100 * total_income, 2),
            })
        if wants_pct > 30:
            advice_items.append({
                "title": "Control Discretionary Spending",
                "description": f"Wants/entertainment ({wants_pct:.1f}%) exceeds 30%. Cut back on non-essentials.",
                "priority": "medium",
                "potential_savings": round((wants_pct - 30) / 100 * total_income, 2),
            })

    # Emergency fund
    monthly_expenses = total_expenses / max(1, len(set([t.get("date", "")[:7] for t in transactions if t.get("date")])))
    emergency_fund = monthly_expenses * 3
    advice_items.append({
        "title": "Build an Emergency Fund",
        "description": f"Target 3 months of expenses ({emergency_fund:.0f} MAD) in a liquid savings account.",
        "priority": "high" if net_balance < emergency_fund else "low",
        "potential_savings": None,
    })

    # Category-specific tips
    food = categories.get("Food", 0)
    if food > total_income * 0.2:
        tips.append(f"Food spending ({food:.0f} MAD) is high — try meal prep and cooking at home to save 20-30%.")
        action_plan.append("Create a weekly meal plan and grocery list to reduce food costs.")

    entertainment = categories.get("Entertainment", 0)
    if entertainment > 0:
        tips.append(f"Review your subscriptions — you may be paying for services you don't use frequently.")

    transport = categories.get("Transport", 0)
    if transport > total_income * 0.15:
        tips.append("Consider carpooling, public transport, or optimizing routes to reduce fuel costs.")

    # Goal-specific advice
    if goal:
        goal_lower = goal.lower()
        if any(k in goal_lower for k in ["car", "voiture", "auto"]):
            car_price = 150000
            monthly_save = net_balance * 0.5 if net_balance > 0 else total_income * 0.1
            months_needed = car_price / max(monthly_save, 1)
            advice_items.append({
                "title": "Car Savings Plan",
                "description": f"Save {monthly_save:.0f} MAD/month to buy a car in ~{months_needed:.0f} months.",
                "priority": "medium",
                "potential_savings": None,
            })
            action_plan.append(f"Open a dedicated savings account and transfer {monthly_save:.0f} MAD monthly for your car fund.")

        elif any(k in goal_lower for k in ["house", "maison", "appartement", "appart"]):
            advice_items.append({
                "title": "Real Estate Savings Plan",
                "description": "Target 20% down payment. Focus on maximizing income and minimizing debts first.",
                "priority": "medium",
                "potential_savings": None,
            })
            action_plan.append("Consult a CIH Bank advisor about the 'Fogarim' or 'Fogaloge' mortgage guarantee programs.")

        elif any(k in goal_lower for k in ["vacation", "travel", "voyage", "vacances"]):
            monthly_save = min(net_balance * 0.3, total_income * 0.05) if net_balance > 0 else 500
            advice_items.append({
                "title": "Travel Fund",
                "description": f"Set aside {monthly_save:.0f} MAD/month in a travel fund.",
                "priority": "low",
                "potential_savings": None,
            })

    # Default tips
    tips.extend([
        "Track every expense — awareness is the first step to financial improvement.",
        "Pay yourself first: transfer to savings before spending on wants.",
        "Negotiate bills annually — insurance, internet, and phone plans can often be reduced.",
        "Use the envelope budgeting method to limit cash spending in each category.",
    ])

    if not action_plan:
        action_plan = [
            "Review your spending weekly for the next month.",
            "Set a monthly budget for each category and stick to it.",
            "Automate savings transfers on payday.",
        ]

    return {
        "advice": advice_items,
        "tips": tips[:4],
        "summary": {
            "totalIncome": total_income,
            "totalExpenses": total_expenses,
            "netBalance": net_balance,
            "savingsRate": savings_rate,
            "savingsOpportunity": round(total_income * 0.2 - max(net_balance, 0), 2) if savings_rate < 20 else 0,
            "riskLevel": analysis.get("risk_level", "unknown"),
        },
        "action_plan": action_plan,
        "goal": goal,
    }

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from collections import defaultdict
from dateutil import parser as date_parser


def safe_parse_date(date_str: Any) -> Optional[datetime]:
    if not date_str:
        return None
    try:
        if isinstance(date_str, datetime):
            return date_str
        return date_parser.parse(str(date_str))
    except Exception:
        return None


def analyze_transactions(transactions: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not transactions:
        return {
            "total_income": 0,
            "total_expenses": 0,
            "net_balance": 0,
            "savings_rate": 0,
            "transaction_count": 0,
            "spending_by_category": {},
            "monthly_breakdown": [],
            "top_expenses": [],
            "insights": ["No transactions found."],
            "recommendations": ["Upload your bank statement to get started."],
            "risk_level": "unknown",
        }

    df = pd.DataFrame(transactions)

    # Normalize columns
    df["amount"] = pd.to_numeric(df.get("amount", 0), errors="coerce").fillna(0)
    df["type"] = df.get("type", "EXPENSE").fillna("EXPENSE").str.upper()
    df["category"] = df.get("category", "Uncategorized").fillna("Uncategorized")
    df["description"] = df.get("description", "").fillna("")

    df["parsed_date"] = df.get("date", None).apply(safe_parse_date)
    df["year_month"] = df["parsed_date"].apply(
        lambda d: d.strftime("%Y-%m") if d else "Unknown"
    )

    income_df = df[df["type"] == "INCOME"]
    expense_df = df[df["type"] == "EXPENSE"]

    total_income = float(income_df["amount"].sum())
    total_expenses = float(expense_df["amount"].sum())
    net_balance = total_income - total_expenses
    savings_rate = (net_balance / total_income * 100) if total_income > 0 else 0

    # Spending by category
    category_spending = (
        expense_df.groupby("category")["amount"]
        .sum()
        .sort_values(ascending=False)
        .to_dict()
    )
    category_spending = {k: round(float(v), 2) for k, v in category_spending.items()}

    # Monthly breakdown
    monthly = []
    for month, group in df.groupby("year_month"):
        if month == "Unknown":
            continue
        month_income = float(group[group["type"] == "INCOME"]["amount"].sum())
        month_expenses = float(group[group["type"] == "EXPENSE"]["amount"].sum())
        monthly.append({
            "month": month,
            "income": round(month_income, 2),
            "expenses": round(month_expenses, 2),
            "net": round(month_income - month_expenses, 2),
            "savings_rate": round((month_income - month_expenses) / month_income * 100 if month_income > 0 else 0, 1),
        })
    monthly.sort(key=lambda x: x["month"])

    # Top expenses
    top_expenses = (
        expense_df.nlargest(5, "amount")[["amount", "category", "description", "date"]]
        .to_dict("records")
    )
    top_expenses = [{k: (round(v, 2) if isinstance(v, float) else v) for k, v in t.items()} for t in top_expenses]

    # Average monthly income/expenses
    num_months = max(len(set(df["year_month"].tolist()) - {"Unknown"}), 1)
    avg_monthly_income = total_income / num_months
    avg_monthly_expenses = total_expenses / num_months

    # Insights
    insights = generate_insights(
        total_income, total_expenses, net_balance, savings_rate,
        category_spending, monthly, avg_monthly_income, avg_monthly_expenses
    )

    recommendations = generate_recommendations(
        savings_rate, category_spending, total_income, avg_monthly_expenses
    )

    risk_level = assess_risk(savings_rate, net_balance, total_income)

    return {
        "total_income": round(total_income, 2),
        "totalIncome": round(total_income, 2),
        "total_expenses": round(total_expenses, 2),
        "totalExpenses": round(total_expenses, 2),
        "net_balance": round(net_balance, 2),
        "netBalance": round(net_balance, 2),
        "savings_rate": round(savings_rate, 1),
        "transaction_count": len(transactions),
        "spending_by_category": category_spending,
        "categories": category_spending,
        "monthly_breakdown": monthly,
        "monthly": {m["month"]: {"income": m["income"], "expenses": m["expenses"]} for m in monthly},
        "top_expenses": top_expenses,
        "avg_monthly_income": round(avg_monthly_income, 2),
        "avg_monthly_expenses": round(avg_monthly_expenses, 2),
        "insights": insights,
        "recommendations": recommendations,
        "risk_level": risk_level,
    }


def generate_insights(
    income: float, expenses: float, net: float, savings_rate: float,
    categories: Dict, monthly: List, avg_income: float, avg_expenses: float
) -> List[str]:
    insights = []

    if savings_rate >= 20:
        insights.append(f"Excellent! Your savings rate is {savings_rate:.1f}%, which exceeds the recommended 20%.")
    elif savings_rate >= 10:
        insights.append(f"Your savings rate is {savings_rate:.1f}%. Aim for 20% to build financial security.")
    elif savings_rate > 0:
        insights.append(f"Your savings rate is {savings_rate:.1f}%. Try to increase this to at least 20%.")
    else:
        insights.append(f"⚠️ Your expenses exceed your income by {abs(net):.2f} MAD. Immediate action needed.")

    if categories:
        top_cat = max(categories.items(), key=lambda x: x[1])
        top_pct = (top_cat[1] / expenses * 100) if expenses > 0 else 0
        insights.append(f"Highest spending: {top_cat[0]} ({top_pct:.1f}% of total expenses, {top_cat[1]:.2f} MAD).")

    if len(monthly) >= 2:
        last = monthly[-1]
        prev = monthly[-2]
        change = last["expenses"] - prev["expenses"]
        if change > 0:
            insights.append(f"Expenses increased by {change:.2f} MAD compared to last month.")
        else:
            insights.append(f"Expenses decreased by {abs(change):.2f} MAD compared to last month. Well done!")

    if avg_income > 0:
        essential_ratio = (avg_expenses / avg_income) * 100
        if essential_ratio > 80:
            insights.append(f"You are spending {essential_ratio:.1f}% of your income on expenses — consider cutting non-essentials.")

    return insights


def generate_recommendations(
    savings_rate: float, categories: Dict, income: float, avg_expenses: float
) -> List[str]:
    recs = []

    if savings_rate < 20:
        target_savings = income * 0.2
        current_savings = income - avg_expenses
        gap = target_savings - current_savings
        recs.append(f"Reduce monthly expenses by {gap:.0f} MAD to reach a 20% savings rate.")

    food_spending = categories.get("Food", 0)
    if food_spending > income * 0.15:
        recs.append(f"Food spending ({food_spending:.0f} MAD) is high — consider meal planning to save up to 20%.")

    entertainment = categories.get("Entertainment", 0)
    if entertainment > income * 0.1:
        recs.append(f"Entertainment ({entertainment:.0f} MAD) exceeds 10% of income — review subscriptions.")

    if categories.get("Uncategorized", 0) > income * 0.1:
        recs.append("Many transactions are uncategorized — add descriptions to better track spending.")

    if not recs:
        recs.append("Your spending habits look healthy. Continue maintaining your budget discipline.")
        recs.append("Consider investing your savings in a term deposit (DAT) for additional returns.")

    return recs


def assess_risk(savings_rate: float, net_balance: float, income: float) -> str:
    if net_balance < 0 or savings_rate < 0:
        return "high"
    elif savings_rate < 10:
        return "medium"
    elif savings_rate < 20:
        return "low"
    else:
        return "minimal"

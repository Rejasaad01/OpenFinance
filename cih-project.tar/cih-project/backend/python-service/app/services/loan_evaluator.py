from typing import Dict, Any, List, Optional


def evaluate_loan_eligibility(
    monthly_income: float,
    monthly_expenses: float,
    requested_amount: float,
    duration_months: int,
    transactions: Optional[List[Dict]] = None,
) -> Dict[str, Any]:
    disposable_income = monthly_income - monthly_expenses
    monthly_payment = requested_amount / max(duration_months, 1)
    debt_to_income_ratio = monthly_payment / max(monthly_income, 1)
    savings_rate = disposable_income / max(monthly_income, 1)

    score = 100.0
    recommendations: List[str] = []
    suggestions: List[str] = []

    # Income check
    if monthly_income < 2000:
        score -= 35
        recommendations.append("Minimum income of 2,000 MAD required for most loan products.")
    elif monthly_income < 5000:
        score -= 10
        suggestions.append("Income above 5,000 MAD improves eligibility significantly.")

    # Savings rate
    if savings_rate < 0.1:
        score -= 30
        recommendations.append("Improve savings rate to at least 10% of monthly income.")
    elif savings_rate < 0.2:
        score -= 15
        suggestions.append("A savings rate of 20% would strengthen your application.")

    # Debt-to-income ratio
    if debt_to_income_ratio > 0.5:
        score -= 35
        recommendations.append("Monthly payment exceeds 50% of income. Reduce loan amount or extend duration.")
    elif debt_to_income_ratio > 0.35:
        score -= 20
        recommendations.append("Monthly payment is between 35%-50% of income. Consider extending the loan term.")
    elif debt_to_income_ratio > 0.25:
        score -= 10
        suggestions.append("Monthly payment is manageable but consider extending duration for more comfort.")

    # Transaction analysis bonus
    if transactions:
        income_transactions = [t for t in transactions if t.get("type", "").upper() == "INCOME"]
        if len(income_transactions) >= 6:
            score += 5
            suggestions.append("Regular income history detected — positive indicator for lenders.")

        expense_transactions = [t for t in transactions if t.get("type", "").upper() == "EXPENSE"]
        if expense_transactions:
            avg_expense = sum(t.get("amount", 0) for t in expense_transactions) / len(expense_transactions)
            if avg_expense < monthly_income * 0.6:
                score += 5
                suggestions.append("Controlled spending pattern detected — positive indicator.")

    score = max(0, min(100, score))
    eligible = score >= 50

    max_loan_amount = monthly_income * 48 * 0.35
    max_monthly_payment = monthly_income * 0.35
    recommended_duration = max(12, int(requested_amount / max_monthly_payment))

    risk_assessment = _get_risk_assessment(score)

    return {
        "eligible": eligible,
        "is_eligible": eligible,
        "eligibility_score": round(score, 1),
        "score": round(score, 1),
        "max_loan_amount": round(max_loan_amount, 2),
        "maxLoanAmount": round(max_loan_amount, 2),
        "monthly_payment": round(monthly_payment, 2),
        "monthlyPayment": round(monthly_payment, 2),
        "max_monthly_payment": round(max_monthly_payment, 2),
        "recommended_duration_months": recommended_duration,
        "debt_to_income_ratio": round(debt_to_income_ratio, 3),
        "debtToIncomeRatio": round(debt_to_income_ratio, 3),
        "savings_rate": round(savings_rate, 3),
        "monthly_income": round(monthly_income, 2),
        "monthly_expenses": round(monthly_expenses, 2),
        "disposable_income": round(disposable_income, 2),
        "recommendations": recommendations,
        "suggestions": suggestions,
        "risk_assessment": risk_assessment,
        "analysis_summary": {
            "requested": requested_amount,
            "duration_months": duration_months,
            "total_repayment": round(monthly_payment * duration_months, 2),
            "effective_rate": "0% (simulation)",
        },
    }


def _get_risk_assessment(score: float) -> str:
    if score >= 80:
        return "Very Low Risk — Excellent candidate"
    elif score >= 65:
        return "Low Risk — Good candidate"
    elif score >= 50:
        return "Medium Risk — Conditionally eligible"
    elif score >= 35:
        return "High Risk — Additional guarantees required"
    else:
        return "Very High Risk — Not recommended at this time"
